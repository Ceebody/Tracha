package com.example.trachax;

public class ReadWriteUserDetails {
    public String email,idNumber,contactNumber;
    public ReadWriteUserDetails(String email,String idNumber,String contactNumber){
        this.email = email;
        this.idNumber = idNumber;
        this.contactNumber = contactNumber;

    }
}
